<?php
$a = 90;
$b = 91;
  if ($a % 2 == 0)
 
  { //Kondisi
    echo "$a adalah angka genap Genap"; //Kondisi true
}
  else {
    echo "$a adalah angka Ganjil"; //Kondisi false
}

echo "<br>";

    if ($b % 2 == 0)
  { //Kondisi
    echo "$b adalah angka genap Genap"; //Kondisi true
}
  else {
    echo "$b adalah angka Ganjil"; //Kondisi false
}
    
?>