<?php
$username = "admin";
$password = "qwerty";
  if ($username == "admin")
  { 
    echo "username dan password sesuai hak akses diberikan"; 
}
  else
 { 
    echo "username atau password tidak sesuai";
 }
?>