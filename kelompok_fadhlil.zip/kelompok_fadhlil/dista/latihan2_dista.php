<?php
$a = 20;
$b = 200;
  if ($a < $b)
  { 
    echo "$a lebih kecil dari $b"; 
}
    if ($a > $b)
 { 
    echo "$a lebih besar dari $b";
 }
if ($a == $b)
 { 
    echo "$a sama dengan $b";
 }
?>
