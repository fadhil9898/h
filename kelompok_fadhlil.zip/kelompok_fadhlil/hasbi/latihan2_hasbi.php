<?php
$a = 30;
$b = 300;
  if ($a < $b)
  { 
    echo "$a lebih kecil dari $b"; 
}
    if ($a > $b)
 { 
    echo "$a lebih besar dari $b";
 }
if ($a == $b)
 { 
    echo "$a sama dengan $b";
 }
?>
