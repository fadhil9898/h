<?php
$a = 10;
$b = 100;
  if ($a < $b)
  { 
    echo "$a lebih kecil dari $b"; 
}
    if ($a > $b)
 { 
    echo "$a lebih besar dari $b";
 }
if ($a == $b)
 { 
    echo "$a sama dengan $b";
 }
?>
